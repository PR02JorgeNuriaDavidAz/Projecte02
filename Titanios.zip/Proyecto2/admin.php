<!DOCTYPE html>
<html>
<head>
	<title>PR02_J_N_D</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script type="text/javascript" src="js/main.js"></script>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<meta charset="utf-8">
</head>
<body>
	

	
	<div id="cabecera" class="row">

		<form action="principal.php" method="REQUEST">

			<?php
				error_reporting(0);
				session_start();


			if(isset($_REQUEST['cerrarsesion'])){
				
				session_destroy();
				
				header('location: index.html');
			}
			if (isset($_SESSION['usuario'])) {
				header('principal.php');
				
				echo "<div id='sesion'><a href='principal.php?cerrarsesion' id='sesioncolor'>Cerrar sesión</a></div>";
				

			}
			?>
		</form>
		</div>		
		
	</div>
	<div id="contenedor_izq">

	</div>
	<div id="contenedor_derch">
		
	</div>
	<div id="contenedor_central">
		<div class="col-lg-12" style="text-align: center;">
			<?php
				$conexion=mysqli_connect("sql206.mipropia.com", "mipc_21057600", "casamia1234", "mipc_21057600_bd_empresa");	
				error_reporting(0);
				session_start();

				$estado=1;
				
				// echo "<div id='contenedor_central'>";
					echo "<table class='table'>";
						echo "<thead>";
							echo "<tr>";
								echo "<th class='centro'>Nombre de usuario</th>";
								echo "<th class='centro'>Nombre del recurso</th>";
								echo "<th class='centro'>Descripcion incidencia</th>";
								echo "<th class='centro'>Fecha Incidencia</th>";
								echo "<th class='centro'>Estado</th>";
							echo "</tr>";
						echo "</thead>";
						echo "<tbody>";
				
				$sql="SELECT DISTINCT tbl_incidencia.idIncidencia, tbl_recurso.idrecurso, tbl_usuario.nombreUsuario, tbl_recurso.nombreRecursos, tbl_incidencia.descripcionIncidencia, tbl_incidencia.fechaIncidencia, tbl_incidencia.estado FROM tbl_usuario INNER JOIN tbl_reserva ON tbl_usuario.idUsuario=tbl_reserva.idUsuario INNER JOIN tbl_recurso ON tbl_reserva.idRecurso=tbl_recurso.idRecurso INNER JOIN tbl_incidencia ON tbl_recurso.idRecurso=tbl_incidencia.idRecurso WHERE tbl_incidencia.estado='1' ORDER BY tbl_incidencia.fechaIncidencia DESC";
				$ejecutar=mysqli_query($conexion,$sql);
				if (mysqli_num_rows($ejecutar)>0) {

					while ($numincidencias=mysqli_fetch_array($ejecutar)) {
						echo "<tr class='filas'>";
						echo '<td>'.$numincidencias[nombreUsuario].'</td>';
						echo '<td>'.utf8_encode($numincidencias[nombreRecursos]).'</td>';
						echo '<td>'.$numincidencias[descripcionIncidencia].'</td>';
						echo '<td>'.$numincidencias[fechaIncidencia].'</td>';
						echo '<td>';
						if ($numincidencias[estado]==1) {
							echo "En reparación";
						}else{
							echo "Disponible";
						}
						echo '</td>';

						echo '<td>';
							echo '<form action="admin.php" method=POST>';
							echo "<input type=hidden name=fechaIncidencia value='$numincidencias[fechaIncidencia]'>";

								echo '<input type=submit name=eliminar value=Reparado>';
									$value=$_POST['fechaIncidencia'];
									if(isset($value)) {
										$q="DELETE FROM tbl_incidencia WHERE tbl_incidencia.fechaIncidencia='$value'";
										$qs=mysqli_query($conexion, $q);
									}
							echo '</form>';
						echo '</td>';

						echo "</tr>";
					}
					echo "</tbody>";
					echo "</table>";
				}
			?>
			
		</div>
	</div>
</body>
</html>